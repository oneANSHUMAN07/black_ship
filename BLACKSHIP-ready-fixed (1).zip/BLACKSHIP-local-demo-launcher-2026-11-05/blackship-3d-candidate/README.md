# BLACKSHIP

BLACKSHIP is a local brand-governance prototype. The workspace includes Brand DNA, a deterministic content auditor, reviewer decisions, and downloadable reports.

## Run locally

**Prerequisite:** Node.js

1. On Windows, double-click `start-blackship.bat`. It installs dependencies if needed, starts the app, and opens `/app` in your browser.
2. Or install dependencies with `npm install --legacy-peer-deps`, then run `npm run dev`.

The workspace currently saves Brand DNA, audit history, and review decisions in this browser on this device. Login and server storage will be connected later.
