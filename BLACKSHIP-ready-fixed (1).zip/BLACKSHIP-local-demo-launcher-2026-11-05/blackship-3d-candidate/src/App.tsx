import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { Features } from './components/Features';
import { HowItWorks } from './components/HowItWorks';
import { AboutSection } from './components/AboutSection';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
import { WorkspaceApp } from './components/WorkspaceApp';

export default function App() {
  if (window.location.pathname === '/app') return <WorkspaceApp />;

  const scrollToFeatures = () => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  const scrollToHowItWorks = () => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div className="min-h-screen bg-[#060608] text-[#f4f4f5] flex flex-col selection:bg-white selection:text-black">
      <Navbar onExploreClick={scrollToFeatures} onHowItWorksClick={scrollToHowItWorks} onGetStartedClick={() => window.location.assign('/app')} />
      <main className="flex-1">
        <Hero onExploreClick={scrollToFeatures} onSeeHowItWorksClick={scrollToHowItWorks} />
        <TrustStrip />
        <Features />
        <HowItWorks />
        <AboutSection />
        <CtaSection />
      </main>
      <Footer />
    </div>
  );
}
